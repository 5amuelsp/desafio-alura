document.getElementById('encrypt_btn').addEventListener('click', function() {
    const text = document.getElementById('text__area').value;
    const encryptedText = encryptText(text);
    updateResult(encryptedText);
});

document.getElementById('decrypt_btn').addEventListener('click', function() {
    const text = document.getElementById('text__area').value;
    const decryptedText = decryptText(text);
    updateResult(decryptedText);
});

function encryptText(text) {
    return text.replace(/e/g, 'enter')
               .replace(/i/g, 'imes')
               .replace(/a/g, 'ai')
               .replace(/o/g, 'ober')
               .replace(/u/g, 'ufat');
}

function decryptText(text) {
    return text.replace(/enter/g, 'e')
               .replace(/imes/g, 'i')
               .replace(/ai/g, 'a')
               .replace(/ober/g, 'o')
               .replace(/ufat/g, 'u');
}

function updateResult(resultText) {
    const resultContent = document.getElementById('result__content');
    resultContent.innerHTML = `<p>${resultText}</p>`;
}